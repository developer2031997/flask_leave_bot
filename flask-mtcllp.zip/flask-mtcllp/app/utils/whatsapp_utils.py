import logging
from flask import current_app, jsonify
import json
import requests

# from app.services.openai_service import generate_response
import re


def log_http_response(response):
    logging.info(f"Status: {response.status_code}")
    logging.info(f"Content-type: {response.headers.get('content-type')}")
    logging.info(f"Body: {response.text}")


def get_text_message_input(recipient, text):
    return json.dumps(
        {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": recipient,
            "type": "text",
            "text": {"preview_url": False, "body": text},
        }
    )


# def generate_response(response):
#     # Return text in uppercase
#     return response.upper()


def send_message(data):
    headers = {
        "Content-type": "application/json",
        "Authorization": f"Bearer {current_app.config['ACCESS_TOKEN']}",
    }

    url = f"https://graph.facebook.com/{current_app.config['VERSION']}/{current_app.config['PHONE_NUMBER_ID']}/messages"

    try:
        response = requests.post(
            url, data=data, headers=headers, timeout=1
        )  # 10 seconds timeout as an example
        response.raise_for_status()  # Raises an HTTPError if the HTTP request returned an unsuccessful status code
        print(f"Run Status: {response.raise_for_status()}")
        
    except requests.Timeout:
        logging.error("Timeout occurred while sending message")
        return jsonify({"status": "error", "message": "Request timed out"}), 408
    except (
        requests.RequestException
    ) as e:  # This will catch any general request exception
        logging.error(f"Request failed due to: {e}")
        return jsonify({"status": "error", "message": "Failed to send message"}), 500
    else:
        # Process the response as normal
        log_http_response(response)
        return response


def process_text_for_whatsapp(text):
    # Remove brackets
    pattern = r"\【.*?\】"
    # Substitute the pattern with an empty string
    text = re.sub(pattern, "", text).strip()

    # Pattern to find double asterisks including the word(s) in between
    pattern = r"\*\*(.*?)\*\*"

    # Replacement pattern with single asterisks
    replacement = r"*\1*"

    # Substitute occurrences of the pattern with the replacement
    whatsapp_style_text = re.sub(pattern, replacement, text)

    return whatsapp_style_text


# def process_whatsapp_message(body):
#     wa_id = body["entry"][0]["changes"][0]["value"]["contacts"][0]["wa_id"]
#     name = body["entry"][0]["changes"][0]["value"]["contacts"][0]["profile"]["name"]

#     message = body["entry"][0]["changes"][0]["value"]["messages"][0]
#     message_body = message["text"]["body"]

#     # TODO: implement custom function here
#     # response = generate_response(message_body)

#     # OpenAI Integration
#     response = generate_response(message_body, wa_id, name)
#     response = process_text_for_whatsapp(response)

#     data = get_text_message_input(current_app.config["RECIPIENT_WAID"], response)
#     send_message(data)

# import requests
# import fitz  # PyMuPDF for PDFs
# import os

# ACCESS_TOKEN = "YOUR_WHATSAPP_API_ACCESS_TOKEN"
# MEDIA_BASE_URL = "https://graph.facebook.com/v19.0"

def process_whatsapp_message(body):
    try:
        wa_id = body["entry"][0]["changes"][0]["value"]["contacts"][0]["wa_id"]
        name = body["entry"][0]["changes"][0]["value"]["contacts"][0]["profile"]["name"]
        messages = body.get("entry", [])[0].get("changes", [])[0].get("value", {}).get("messages", [])
        
        if not messages:
            return
        
        wa_id = messages[0]["from"]
        name = body.get("entry", [])[0].get("changes", [])[0].get("value", {}).get("contacts", [])[0].get("profile", {}).get("name", "User")

        # 🟢 Handle Text Messages
        if "text" in messages[0]:
            message_body = messages[0]["text"]["body"]
            # print(f"from new function  message_body:- {message_body}")
            response = generate_response(message_body, wa_id, name)
            # print(f"from new function response:- {response}")
            responses = process_text_for_whatsapp(response)
            # print(f"from new function responses:- {responses}")
            data = get_text_message_input(current_app.config["RECIPIENT_WAID"], response)
            # print(f"from new function data:- {data}")
            answer = send_message(data)
            # print(f"from new function answer :- {answer}")
            # response = f"📩 You sent: {message_body}"
            # send_message(wa_id, response)

        # # 🟢 Handle Document (PDF, Word, etc.)
        # elif "document" in messages[0]:
        #     media_id = messages[0]["document"]["id"]
        #     filename = messages[0]["document"]["filename"]
        #     mime_type = messages[0]["document"]["mime_type"]

        #     file_path = download_media(media_id, filename)
        #     # send_message(wa_id, f"📄 Received `{filename}` ({mime_type}). Processing...")

        #     # If it's a PDF, extract text
        #     if mime_type == "application/pdf":
        #         text = extract_text_from_pdf(file_path)
        #         # send_message(wa_id, f"🔍 Extracted Text:\n\n{text[:1000]}")  # Limit output

        # # 🟢 Handle Images
        # elif "image" in messages[0]:
        #     media_id = messages[0]["image"]["id"]
        #     filename = f"image_{media_id}.jpg"

        #     file_path = download_media(media_id, filename)
        #     # send_message(wa_id, f"📷 Received an image! Saved as `{filename}`.")

        # # 🟢 Handle Videos
        # elif "video" in messages[0]:
        #     media_id = messages[0]["video"]["id"]
        #     filename = f"video_{media_id}.mp4"

        #     file_path = download_media(media_id, filename)
        #     # send_message(wa_id, f"🎥 Received a video! Saved as `{filename}`.")

        # # 🟢 Handle Audio
        # elif "audio" in messages[0]:
        #     media_id = messages[0]["audio"]["id"]
        #     filename = f"audio_{media_id}.mp3"

        #     file_path = download_media(media_id, filename)
        #     # send_message(wa_id, f"🎵 Received an audio file! Saved as `{filename}`.")

        else:
            print(wa_id, "⚠️ I can only process text, PDFs, images, videos, and audio.")

    except Exception as e:
        print(f"Error processing WhatsApp message: {str(e)}")



def is_valid_whatsapp_message(body):
    """
    Check if the incoming webhook event has a valid WhatsApp message structure.
    """
    return (
        body.get("object")
        and body.get("entry")
        and body["entry"][0].get("changes")
        and body["entry"][0]["changes"][0].get("value")
        and body["entry"][0]["changes"][0]["value"].get("messages")
        and body["entry"][0]["changes"][0]["value"]["messages"][0]
    )
