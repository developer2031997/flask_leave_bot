from functools import wraps
from flask import current_app, jsonify, request
import logging
import hashlib
import hmac

def validate_signature(payload, signature):
    """
    Validate the incoming payload's signature against our expected signature.
    """
    print("🔹 Starting signature validation...")
    print(f"📥 Received Signature: {signature}")

    # Compute expected signature using HMAC with the App Secret
    expected_signature = hmac.new(
        bytes(current_app.config["APP_SECRET"], "utf-8"),
        msg=payload.encode("utf-8"),
        digestmod=hashlib.sha256,
    ).hexdigest()

    print(f"🔑 Expected Signature: {expected_signature}")

    # Compare signatures
    is_valid = hmac.compare_digest(expected_signature, signature)
    
    if is_valid:
        print("✅ Signature is valid.")
    else:
        print("❌ Signature verification failed!")

    return is_valid


def signature_required(f):
    """
    Decorator to ensure that the incoming requests to our webhook are valid and signed with the correct signature.
    """

    @wraps(f)
    def decorated_function(*args, **kwargs):
        print("🔹 Checking request signature...")

        signature_header = request.headers.get("X-Hub-Signature-256")

        if not signature_header:
            print("⚠️ No signature header found!")
            logging.info("Missing signature header!")
            return jsonify({"status": "error", "message": "Missing signature"}), 403

        # Extract signature (remove 'sha256=' prefix)
        # signature = signature_header[7:] if signature_header.startswith("sha256=") else ""
            # Remove 'sha256=' prefix if present
        received_signature = signature_header.replace("sha256=", "").strip()

        print(f"📥 Extracted Signature: {received_signature}")

        # Validate the signature
        if not validate_signature(request.data.decode("utf-8"), received_signature):
            logging.info("Signature verification failed!")
            print("🚨 Request rejected due to invalid signature.")
            return jsonify({"status": "error", "message": "Invalid signature"}), 403

        print("✅ Signature verification passed. Proceeding with request.")
        return f(*args, **kwargs)

    return decorated_function
