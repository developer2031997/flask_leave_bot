import logging
import requests
import json
from flask import jsonify, current_app

def process_whatsapp_message(body):
    """
    Processes incoming WhatsApp messages: 
    - If it's a text message, generates a response.
    - If it's a PDF document, downloads, extracts text, and stores it.
    """

    try:
        # ✅ Validate if it's a proper WhatsApp message
        if not is_valid_whatsapp_message(body):
            return jsonify({"status": "error", "message": "Not a WhatsApp API event"}), 404

        # ✅ Extract sender details
        sender = body["entry"][0]["changes"][0]["value"]["contacts"][0]["wa_id"]
        name = body["entry"][0]["changes"][0]["value"]["contacts"][0]["profile"]["name"]

        # ✅ Extract message details
        message = body["entry"][0]["changes"][0]["value"]["messages"][0]

        # ✅ Handle PDF Documents
        if message.get("type") == "document":
            media_id = message["document"]["id"]
            file_name = message["document"]["filename"]
            logging.info(f"Received PDF: {file_name} from {sender}")

            # Download PDF from WhatsApp API
            pdf_url = f"https://graph.facebook.com/v18.0/{media_id}"
            headers = {"Authorization": f"Bearer {current_app.config['WHATSAPP_ACCESS_TOKEN']}"}
            response = requests.get(pdf_url, headers=headers)

            if response.status_code == 200:
                file_path = f"uploads/{file_name}"
                with open(file_path, "wb") as f:
                    f.write(response.content)

                # Extract text from PDF
                extracted_text = extract_text_from_pdf(file_path)

                # Store extracted text in vector database
                store_pdf_text(file_name, extracted_text)

                return jsonify({"status": "ok", "message": f"PDF '{file_name}' uploaded and processed"}), 200
            else:
                logging.error("Failed to download PDF")
                return jsonify({"status": "error", "message": "Failed to download PDF"}), 500

        # ✅ Handle Text Messages
        elif message.get("type") == "text":
            question = message["text"]["body"]
            logging.info(f"Received Question: {question} from {sender}")

            # Retrieve answer from stored PDFs
            answer = answer_question_from_pdf(question)

            # If no answer from PDFs, use OpenAI to generate a response
            if not answer:
                answer = generate_response(question, sender, name)

            # Format response for WhatsApp and send
            formatted_answer = process_text_for_whatsapp(answer)
            data = get_text_message_input(sender, formatted_answer)
            send_message(data)

            return jsonify({"status": "ok", "answer": formatted_answer}), 200

        # ✅ If message type is unknown
        return jsonify({"status": "error", "message": "Unsupported message type"}), 400

    except json.JSONDecodeError:
        logging.error("Failed to decode JSON")
        return jsonify({"status": "error", "message": "Invalid JSON provided"}), 400

def is_valid_whatsapp_message(body):
    """
    Validates if the incoming request follows WhatsApp API message structure.
    """
    return (
        body.get("object")
        and body.get("entry")
        and body["entry"][0].get("changes")
        and body["entry"][0]["changes"][0].get("value")
        and body["entry"][0]["changes"][0]["value"].get("messages")
        and body["entry"][0]["changes"][0]["value"]["messages"][0]
    )
