import logging
import requests


def exit_confirmation_template(user_phone):
    """Send an Exit button template to the user"""

    url = "https://graph.facebook.com/v17.0/YOUR_WHATSAPP_PHONE_ID/messages"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }

    payload = {
        "messaging_product": "whatsapp",
        "to": user_phone,
        "type": "template",
        "template": {
            "name": "exit_chat_template",  # Your approved template name
            "language": {"code": "en"},
            "components": [
                {
                    "type": "button",
                    "sub_type": "quick_reply",
                    "index": 0,
                    "parameters": [
                        {
                            "type": "payload",
                            "payload": "end_chat"
                        }
                    ]
                }
            ]
        }
    }

    response = requests.post(url, json=payload, headers=headers)

    if response.status_code == 200:
        logging.info("✅ Welcome template sent successfully")
    else:
        logging.error(f"❌ Error sending template: {response.text}")
    
