import requests
import logging
from flask import current_app

def view_and_send_leave_requests_response(user_phone):
    """
    Fetches all employee leave requests and sends them to the admin with Accept and Reject buttons.
    If there are no requests, sends a message to notify the admin.
    """
    url = "https://hub.leave.in/api/all-leave-requests"  # Replace with actual API URL
    headers = {
        "Authorization": "Bearer <your_token>",  # Replace with actual token if required
        "Content-Type": "application/json"
    }

    try:
        # Fetch all leave requests from the API
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        data = response.json()  # Parse the JSON response

        if not data:
            # If no leave requests, send a message to notify the admin
            message_body = "📋 No pending leave requests at the moment."
            payload = {
                "messaging_product": "whatsapp",
                "to": user_phone,
                "type": "text",
                "text": {"body": message_body}
            }
            send_whatsapp_payload(payload)  # Send the no-pending-leave message
            return  # Exit early as there are no leave requests

        # Process each leave request and send them with Accept/Reject buttons
        for leave in data:
            leave_id = leave.get("id", "Unknown")
            employee_name = leave.get("employee", {}).get("user", {}).get("name", "Unknown")
            leave_type = leave.get("leavetype", {}).get("type_name", "Unknown")
            start_date = leave.get("start_date", "Unknown")
            end_date = leave.get("end_date", "Unknown")
            reason = leave.get("reason", "Not provided")
            status = "Pending" if leave.get("is_active") else "Inactive"

            # Format the message body
            message_body = (
                f"📋 *Leave Request* (ID: {leave_id})\n"
                f"👤 *Employee:* {employee_name}\n"
                f"📅 *Start Date:* {start_date}\n"
                f"📅 *End Date:* {end_date}\n"
                f"📅 *Leave Type:* {leave_type}\n"
                f"📝 *Reason:* {reason}\n"
                f"🔄 *Status:* {status}\n\n"
                "What would you like to do?"
            )

            # Create the payload for the Accept/Reject buttons
            payload = {
                "messaging_product": "whatsapp",
                "to": user_phone,
                "type": "interactive",
                "interactive": {
                    "type": "button",
                    "body": {"text": message_body},
                    "action": {
                        "buttons": [
                            {
                                "type": "reply",
                                "reply": {
                                    "id": f"accept_{leave_id}",
                                    "title": "✅ Accept"
                                }
                            },
                            {
                                "type": "reply",
                                "reply": {
                                    "id": f"reject_{leave_id}",
                                    "title": "❌ Reject"
                                }
                            }
                        ]
                    }
                }
            }

            # Send the WhatsApp message with Accept/Reject buttons for each leave request
            send_whatsapp_payload(payload)

    except requests.exceptions.RequestException as e:
        logging.error(f"❌ Error fetching leave requests: {str(e)}")

        # Handle error response
        error_message = f"⚠️ Error fetching leave requests: {str(e)}"
        payload = {
            "messaging_product": "whatsapp",
            "to": user_phone,
            "type": "text",
            "text": {"body": error_message}
        }
        send_whatsapp_payload(payload)

def send_whatsapp_payload(payload):
    """
    Sends a message via WhatsApp using the provided payload.
    """
    url = f'https://graph.facebook.com/v17.0/{current_app.config["PHONE_NUMBER_ID"]}/messages'
    headers = {
        'Authorization': f'Bearer {current_app.config["ACCESS_TOKEN"]}',
        'Content-Type': 'application/json',
    }

    try:
        response = requests.post(url, json=payload, headers=headers)
        if response.status_code == 200:
            logging.info(f"✅ Message sent successfully")
        else:
            logging.error(f"❌ Error sending message: {response.text}")
    except requests.exceptions.RequestException as e:
        logging.error(f"❌ Error sending message: {e}")
