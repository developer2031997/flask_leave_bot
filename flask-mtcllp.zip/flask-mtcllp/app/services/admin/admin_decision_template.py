import logging
from flask import current_app
import requests


def process_admin_decision(admin_phone, button_id):
    """
    Processes the admin's decision (Accept or Reject) on a leave request.
    Sends a notification to the employee about the decision.
    """
    url = f'https://graph.facebook.com/v17.0/{current_app.config["PHONE_NUMBER_ID"]}/messages'
    
    headers = {
        'Authorization': f'Bearer {current_app.config["ACCESS_TOKEN"]}',
        'Content-Type': 'application/json',
    }

    # Extract leave_id and action (accept/reject)
    if button_id.startswith("accept_"):
        leave_id = button_id.replace("accept_", "")
        decision_text = "✅ Your leave request has been *approved* by the admin."
        status = "accepted"
    elif button_id.startswith("reject_"):
        leave_id = button_id.replace("reject_", "")
        decision_text = "❌ Your leave request has been *rejected* by the admin."
        status = "rejected"
    else:
        return

    # Fetch leave request details to get employee phone
    leave_api_url = f"https://hub.leave.in/api/leaves/{leave_id}"
    response = requests.get(leave_api_url, headers=headers)

    if response.status_code != 200:
        logging.error(f"❌ Error fetching leave details: {response.text}")
        return

    leave_data = response.json()
    employee_phone = leave_data.get("employee", {}).get("phone", "")

    if not employee_phone:
        logging.error("❌ No phone number found for employee.")
        return

    # Notify employee
    payload = {
        "messaging_product": "whatsapp",
        "to": employee_phone,
        "type": "text",
        "text": {"body": decision_text}
    }

    response = requests.post(url, json=payload, headers=headers)

    if response.status_code == 200:
        logging.info(f"✅ Leave request {status} message sent to employee.")
    else:
        logging.error(f"❌ Error notifying employee: {response.text}")

    # Update leave request status in the database (example API call)
    update_url = f"https://hub.leave.in/api/update-leave-status/{leave_id}"
    update_payload = {"status": status}
    requests.post(update_url, json=update_payload, headers=headers)
