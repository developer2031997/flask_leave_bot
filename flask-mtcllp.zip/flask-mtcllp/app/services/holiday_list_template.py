import requests


def holiday_lists_template(user_phone, message):

    url = "https://graph.facebook.com/v17.0/YOUR_WHATSAPP_PHONE_ID/messages"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }

    try:
        response = requests.post(url, headers=headers, json=message)
        response.raise_for_status()
        print("Message sent successfully!")
    except requests.exceptions.RequestException as e:
        print(f"Error sending message: {e}")

    # Example Usage
    holiday_list = [
        {"id": 1, "name": "New Year", "date": "2024-01-01"},
        {"id": 2, "name": "Republic Day", "date": "2024-01-26"},
        {"id": 3, "name": "Independence Day", "date": "2024-08-15"},
        {"id": 4, "name": "Christmas", "date": "2024-12-25"}
    ]


    holiday_message = {
        "messaging_product": "whatsapp",
        "to": user_phone,
        "type": "template",
        "template": {
            "name": "holiday_list_template",  # Use your created template name
            "language": {"code": "en"},
            "components": [
                {
                    "type": "body",
                    "parameters": [
                        {"type": "text", "text": "📅 *Holiday List*"},
                        {"type": "text", "text": "------------------------------------"},
                        {"type": "text", "text": "| *ID*  | *Name*               | *Date*     |"},
                        {"type": "text", "text": "------------------------------------"}
                    ]
                }
            ]
        }
    }

    # Dynamically add holiday data to the message
    for i, holiday in enumerate(holiday_list, start=1):
        holiday_message["template"]["components"][0]["parameters"].append(
            {"type": "text", "text": f"| {holiday['id']} | {holiday['name']} | {holiday['date']} |"}
        )

    holiday_message["template"]["components"][0]["parameters"].append(
        {"type": "text", "text": "------------------------------------"}
    )

        # Send the message
    url = "https://graph.facebook.com/v17.0/YOUR_WHATSAPP_PHONE_ID/messages"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }

    try:
        response = requests.post(url, headers=headers, json=holiday_message)
        response.raise_for_status()  # Raises an HTTPError if the response code was unsuccessful (4xx or 5xx)

        # If the request is successful, log the response
        if response.status_code == 200:
            print("✅ Holiday list message sent successfully!")
            return response.json()  # You can return the response object for further processing if needed
        else:
            print(f"❌ Error sending message: {response.text}")
            return None

    except requests.exceptions.RequestException as e:
        # Catch any exceptions and log the error
        print(f"⚠️ Error sending message: {e}")
        return None

