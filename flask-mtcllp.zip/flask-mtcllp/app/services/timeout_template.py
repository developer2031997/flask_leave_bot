from threading import Timer
from datetime import datetime, timedelta

from app.views import send_whatsapp_message

# Dictionary to store last activity timestamp for each user
user_last_activity = {}

# Timeout period in minutes (e.g., 15 minutes)
TIMEOUT_PERIOD = 15  # You can adjust this value


# Function to check inactivity
def check_inactivity():
    """Checks all users' inactivity and sends timeout message if necessary."""
    current_time = datetime.now()
    for wa_id, last_activity in list(user_last_activity.items()):
        if current_time - last_activity > timedelta(minutes=TIMEOUT_PERIOD):
            # If the user has been inactive for longer than the timeout period, send timeout message
            send_timeout_message(wa_id)
            # Remove the user from the activity tracking
            user_last_activity.pop(wa_id, None)

    # Schedule the next inactivity check (e.g., every 60 seconds)
    Timer(60, check_inactivity).start()  # Checks every minute

# Start the inactivity check when the app starts
check_inactivity()


def send_timeout_message(wa_id):
    """Send a timeout message to the user."""
    send_whatsapp_message({
        "recipient_type": "individual",
        "to": wa_id,
        "type": "text",
        "text": {
            "body": "Your session has timed out due to inactivity. Please type 'hi' to restart the conversation."
        }
    })
