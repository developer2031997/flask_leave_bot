import requests
import logging

def send_whatsapp_home_menu(wa_id):
    """
    Sends the common home menu with available options and handles the response.
    This function combines the message body and button options into one call.
    """

    # Define your API URL and headers
    url = "https://graph.facebook.com/v14.0/<your-phone-number-id>/messages"  # Replace with your actual URL
    headers = {
        "Authorization": "Bearer <your-access-token>",  # Replace with your actual token
        "Content-Type": "application/json"
    }

    payload = {
        "messaging_product": "whatsapp",
        "to": wa_id,
        "type": "template",
        "template": {
            "name": "employee_home_menu ",  # Your Meta template name
            "language": {"code": "en_US"},
            "components": [
                               {
                "type": "button",  # ✅ Correct component type
                "sub_type": "quick_reply",
                "index": "0",
                "parameters": [
                    {
                        "type": "payload",
                        "payload": "view_pending_leaves"  # Employee button ID
                    }
                ]
            },
                           {
                "type": "button",  # ✅ Correct component type
                "sub_type": "quick_reply",
                "index": "1",
                "parameters": [
                    {
                        "type": "payload",
                        "payload": "apply_leave"  # Employee button ID
                    }
                ]
            },
                           {
                "type": "button",  # ✅ Correct component type
                "sub_type": "quick_reply",
                "index": "2",
                "parameters": [
                    {
                        "type": "payload",
                        "payload": "holidays_list"  # Employee button ID
                    }
                ]
            },
                           {
                "type": "button",  # ✅ Correct component type
                "sub_type": "quick_reply",
                "index": "3",
                "parameters": [
                    {
                        "type": "payload",
                        "payload": "exit_chat"  # Employee button ID
                    }
                ]
            }
            ]
        }
    }

 

    # Send the request to the WhatsApp API
    try:
        response = requests.post(url, json=payload, headers=headers)
        
        # Check if the response status is OK
        if response.status_code == 200:
            logging.info("✅ Home menu sent successfully")
        else:
            logging.error(f"❌ Error sending home menu: {response.text}")
            
    except requests.exceptions.RequestException as e:
        logging.error(f"❌ Exception occurred while sending home menu: {str(e)}")
