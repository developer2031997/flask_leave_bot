import logging
from flask import current_app
import requests


def confirm_leave_request(user_phone, leave_details, reason):
    """
    Sends confirmation message after receiving leave details in two parts.
    """
    url = f'https://graph.facebook.com/v17.0/{current_app.config["PHONE_NUMBER_ID"]}/messages'
    
    headers = {
        'Authorization': f'Bearer {current_app.config["ACCESS_TOKEN"]}',
        'Content-Type': 'application/json',
    }

    leave_details_message = {
        "messaging_product": "whatsapp",
        "to": user_phone,
        "type": "template",  # Changed to "template" for using the WhatsApp template
        "template": {
            "name": "leave_request_confirmation",  # Template name you defined in Meta (WhatsApp)
            "language": {
                "code": "en"  # Language code for the template
            },
            "components": [
                {
                    "type": "body",
                    "parameters": [
                        {
                            "type": "text",
                            "text": f"✅ Your leave request has been submitted successfully! 🎉"
                        },
                        {
                            "type": "text",
                            "text": f"➡️ Leave Type: {leave_details['leave_type']}"
                        },
                        {
                            "type": "text",
                            "text": f"➡️ Start Date: {leave_details['start_date']}"
                        },
                        {
                            "type": "text",
                            "text": f"➡️ End Date: {leave_details['end_date']}"
                        },
                        {
                            "type": "text",
                            "text": f"➡️ Half Day: {leave_details['half_day']}"
                        }
                    ]
                }
            ]
        }
    }

    # Send leave details message
    response = requests.post(url, json=leave_details_message, headers=headers)
    if response.status_code == 200:
        logging.info("✅ Leave details message sent successfully")
    else:
        logging.error(f"❌ Error sending leave details message: {response.text}")
