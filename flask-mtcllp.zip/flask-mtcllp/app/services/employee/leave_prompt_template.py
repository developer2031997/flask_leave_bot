import logging
from flask import current_app
import requests


def send_whatsapp_leave_prompt(user_phone):
    """
    Sends a message asking the user to enter leave dates.
    """
    url = f'https://graph.facebook.com/v17.0/{current_app.config["PHONE_NUMBER_ID"]}/messages'
    
    headers = {
        'Authorization': f'Bearer {current_app.config["ACCESS_TOKEN"]}',
        'Content-Type': 'application/json',
    }

    payload = {
        "messaging_product": "whatsapp",
        "to": user_phone,
        "type": "text",
        "text": {
              "body": "📅 Please enter your leave details in this format:\n\n➡️ Start Date: YYYY-MM-DD\n➡️ End Date: YYYY-MM-DD\n➡️ Reason: Your reason for leave\n\nExample: `Start Date: 2024-02-10, End Date: 2024-02-15, Reason: Medical`"
        }
    }

    response = requests.post(url, json=payload, headers=headers)

    if response.status_code == 200:
        logging.info("✅ Leave prompt sent successfully")
    else:
        logging.error(f"❌ Error sending leave prompt: {response.text}")
