import requests

def view_pending_leaves(user_phone):
    """
    Fetches pending leave balance, sends the formatted WhatsApp message, and provides action buttons.
    """
    url = "https://hub.leave.in/api/pending-leaves"  # Replace with actual API URL
    headers = {
        "Authorization": "Bearer <your_token>",  # Replace with actual token
        "Content-Type": "application/json"
    }

    try:
        # Make API request to fetch pending leaves
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        data = response.json()  # Parse response

        # Initialize leave balances
        leave_balances = {
            "Restricted Holiday": 0,
            "Sick Leave": 0,
            "Casual Leave": 0,
            "Earned Leave": 0
        }

        # Extract leave balances from API response
        for leave in data:
            leave_type = leave.get("leavetype", {}).get("type_name", "").lower()
            balance = leave.get("balance_amount", 0)

            if "restricted" in leave_type:
                leave_balances["Restricted Holiday"] = balance
            elif "sick" in leave_type:
                leave_balances["Sick Leave"] = balance
            elif "casual" in leave_type:
                leave_balances["Casual Leave"] = balance
            elif "earned" in leave_type:
                leave_balances["Earned Leave"] = balance

        # Construct leave balance message
        leave_message = (
            "Your Pending Leave Balance: 📅\n\n"
            f"🔹 Restricted Holiday: {leave_balances['Restricted Holiday']}\n"
            f"🔹 Sick Leave: {leave_balances['Sick Leave']}\n"
            f"🔹 Casual Leave: {leave_balances['Casual Leave']}\n"
            f"🔹 Earned Leave: {leave_balances['Earned Leave']}"
        )

        # Define WhatsApp API URL and headers
        api_url = "https://graph.facebook.com/v17.0/YOUR_WHATSAPP_PHONE_ID/messages"  # Replace with actual API endpoint
        api_headers = {
            "Authorization": "Bearer YOUR_ACCESS_TOKEN",  # Replace with actual token
            "Content-Type": "application/json"
        }
        
        # Define payload for WhatsApp message
        payload = {
            "messaging_product": "whatsapp",
            "to": user_phone,
            "type": "text",
            "text": {"body": leave_message}
        }

        # Send the message via API
        send_response = requests.post(api_url, headers=api_headers, json=payload)

        # Check response status
        if send_response.status_code == 200:
            print("✅ Message sent successfully")
        else:
            print(f"❌ Error sending message: {send_response.text}")

    except requests.exceptions.RequestException as e:
        # Handle any errors and send error message
        error_message = f"⚠️ Error fetching leave data: {str(e)}"

        # Define payload for error message
        error_payload = {
            "messaging_product": "whatsapp",
            "to": user_phone,
            "type": "text",
            "text": {"body": error_message}
        }

        # Send the error message via API
        error_response = requests.post(api_url, headers=api_headers, json=error_payload)
        
        if error_response.status_code == 200:
            print("❌ Error message sent successfully")
        else:
            print(f"❌ Error sending error message: {error_response.text}")
