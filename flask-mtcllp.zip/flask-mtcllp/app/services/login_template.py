import logging
from flask import current_app
import requests


def send_whatsapp_login_template(user_phone):
    """
    Sends a login message template to the user after clicking 'Start'.
    """
    url = f'https://graph.facebook.com/v17.0/{current_app.config["PHONE_NUMBER_ID"]}/messages'
    
    headers = {
        'Authorization': f'Bearer {current_app.config["ACCESS_TOKEN"]}',
        'Content-Type': 'application/json',
    }

    payload = {
        "messaging_product": "whatsapp",
        "to": user_phone,
        "type": "template",
        "template": {
            "name": "login_template",  
            "language": {"code": "en_us"},
            "components": [
                {
                    "type": "button",
                    "sub_type": "url",
                    "index": 0,
                    "parameters": [
                        {
                            "type": "text",
                            "text": "https://hub.login.in"
                        }
                    ]
                }
            ]
        }
    }


    response = requests.post(url, json=payload, headers=headers)

    if response.status_code == 200:
        logging.info("✅ Login template sent successfully")
    else:
        logging.error(f"❌ Error sending template: {response.text}")
