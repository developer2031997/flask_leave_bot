import logging
from flask import current_app
import requests


def send_whatsapp_post_login_template(user_phone,user_name):
    """
    Sends a post-login message template to the user after they log in successfully.
    This message includes options to view pending leaves or apply for new leave.
    """
    url = f'https://graph.facebook.com/v17.0/{current_app.config["PHONE_NUMBER_ID"]}/messages'
    
    headers = {
        'Authorization': f'Bearer {current_app.config["ACCESS_TOKEN"]}',
        'Content-Type': 'application/json',
    }

    payload = {
        "messaging_product": "whatsapp",
        "to": user_phone,
        "type": "template",
        "template": {
            "name": "post_login_template",  # Your template name for login success
            "language": {"code": "en_US"},
            "components": [
                {
                    "type": "body",
                    "parameters": [
                        {
                            "type": "text",
                            "text": user_name
                        }
                    ]
                }
            ]
        }
    }

    response = requests.post(url, json=payload, headers=headers)

    if response.status_code == 200:
        logging.info("✅ Post-login template sent successfully")
    else:
        logging.error(f"❌ Error sending post-login template: {response.text}")
