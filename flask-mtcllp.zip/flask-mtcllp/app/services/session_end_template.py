import requests

def session_end_template(wa_id, user_name):
    """Sends a message to inform the user that the session has ended."""
    message = {
        "messaging_product": "whatsapp",
        "to": wa_id,
        "type": "text",
        "text": {
            "body": f"👋 {user_name}, your session has been successfully ended. Thank you for using the service! 🙏"
        }
    }

    # Send the message using the WhatsApp API
    url = "https://graph.facebook.com/v17.0/YOUR_WHATSAPP_PHONE_ID/messages"  # Replace with actual API URL
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",  # Replace with your access token
        "Content-Type": "application/json"
    }

    try:
        response = requests.post(url, headers=headers, json=message)
        response.raise_for_status()
        print(f"✅ Session end message sent to {user_name}")
    except requests.exceptions.RequestException as e:
        print(f"❌ Error sending session end message: {e}")
