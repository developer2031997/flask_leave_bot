import logging
from flask import current_app
import requests


def send_welcome_template(user_phone):
    """
    Sends a pre-approved welcome message template to the user via WhatsApp API.
    """
    url = f'https://graph.facebook.com/v17.0/{current_app.config["PHONE_NUMBER_ID"]}/messages'
    
    headers = {
        'Authorization': f'Bearer {current_app.config["ACCESS_TOKEN"]}',
        'Content-Type': 'application/json',
    }

    payload = {
        "messaging_product": "whatsapp",
        "to": user_phone,
        "type": "template",
        "template": {
            "name": "mtcllp_welcome_template",  # Your approved template name
            "language": {"code": "en"},
            "components": [
                {
                    "type": "button",
                    "sub_type": "quick_reply",
                    "index": 0,
                    "parameters": [
                        {
                            "type": "payload",
                            "payload": "start"
                        }
                    ]
                }
            ]
        }
    }

    print("🔹 Sending request to WhatsApp API...")
    print("📍 URL:", url)
    print("📩 Headers:", headers)
    print("📨 Payload:", payload)

    response = requests.post(url, json=payload, headers=headers)

    print("🔹 Response Status Code:", response.status_code)

    try:
        response_json = response.json()
        print("✅ WhatsApp API Response:", response_json)
    except requests.exceptions.JSONDecodeError:
        print("⚠️ No JSON response received!")
        response_json = {}


    if response.status_code == 200:
        logging.info("✅ Welcome template sent successfully")
    else:
        logging.error(f"❌ Error sending template: {response.text}")
