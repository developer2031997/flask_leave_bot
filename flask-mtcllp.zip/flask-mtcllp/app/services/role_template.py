import requests
import logging
from flask import current_app

def choose_role_template(user_phone):
    """
    Sends a template message asking the user to choose their role (Admin or Employee).
    This message includes action buttons to select between Admin and Employee.
    """
    url = f'https://graph.facebook.com/v17.0/{current_app.config["PHONE_NUMBER_ID"]}/messages'
    
    headers = {
        'Authorization': f'Bearer {current_app.config["ACCESS_TOKEN"]}',
        'Content-Type': 'application/json',
    }

    payload = {
        "messaging_product": "whatsapp",
        "to": user_phone,
        "type": "template",
        "template": {
            "name": "mtcllp_role_template",  # Your template name for role selection
            "language": {"code": "en"},
            "components": [
                {
                "type": "button",  # ✅ Correct component type
                "sub_type": "quick_reply",
                "index": "0",
                "parameters": [
                    {
                        "type": "payload",
                        "payload": "employee"  # Employee button ID
                    }
                ]
            },
            {
                "type": "button",  # ✅ Second button as separate component
                "sub_type": "quick_reply",
                "index": "1",
                "parameters": [
                    {
                        "type": "payload",
                        "payload": "admin"  # Admin button ID
                    }
                ]
            }
        ]
    }
}


    print("🔹 Sending request to WhatsApp API...")
    print("📍 URL:", url)
    print("📩 Headers:", headers)
    print("📨 Payload:", payload)

    response = requests.post(url, json=payload, headers=headers)

    print("🔹 Response Status Code:", response.status_code)

    try:
        response_json = response.json()
        print("✅ WhatsApp API Response:", response_json)
    except requests.exceptions.JSONDecodeError:
        print("⚠️ No JSON response received!")
        response_json = {}

    # response = requests.post(url, json=payload, headers=headers)

    if response.status_code == 200:
        logging.info("✅ Role selection template sent successfully")
    else:
        logging.error(f"❌ Error sending role selection template: {response.text}")
