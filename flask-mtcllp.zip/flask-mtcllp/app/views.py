import logging
import json
import requests
from flask import Blueprint, request, jsonify, current_app

from .decorators.security import signature_required

from app.services.login_template import send_whatsapp_login_template
from app.services.welcome_template import send_welcome_template
from app.services.role_template import choose_role_template
from app.services.post_login_template import send_whatsapp_post_login_template
from app.services.exit_confirmation_template import exit_confirmation_template
from app.services.holiday_list_template import holiday_lists_template
from app.services.session_end_template import session_end_template

from app.services.employee.home_menu_template import send_whatsapp_home_menu
from app.services.employee.pending_leave_template import view_pending_leaves
from app.services.employee.leave_prompt_template import send_whatsapp_leave_prompt
from app.services.employee.confirm_leave_template import confirm_leave_request

from app.services.admin.view_and_send_leave_requests_response import view_and_send_leave_requests_response
from app.services.admin.admin_decision_template import process_admin_decision

from .utils.whatsapp_utils import (
    process_whatsapp_message,
    is_valid_whatsapp_message,
)

webhook_blueprint = Blueprint("webhook", __name__)

# Store user leave request states
user_states = {}


def handle_employee_flow(message_body):
    """
    Handles incoming WhatsApp messages.
    """
    body = request.get_json()

    # Check if it's a WhatsApp status update
    if (
        body.get("entry", [{}])[0]
        .get("changes", [{}])[0]
        .get("value", {})
        .get("statuses")
    ):
        logging.info("Received a WhatsApp status update.")
        return jsonify({"status": "ok"}), 200

    try:
        if is_valid_whatsapp_message(body):
            messages = body["entry"][0]["changes"][0]["value"]["messages"]
            wa_id = messages[0]["from"]
            message_body = messages[0].get("text", {}).get("body", "").strip().lower()
            

            # Handle different user messages
            if message_body == "employee":
                send_whatsapp_login_template(wa_id)
            elif message_body("login"):  # Example: "Login successful, John"
                # user_name = message_body.replace("login successful", "").strip()
                send_whatsapp_post_login_template(wa_id, "akshay")  # Send post-login options
                send_whatsapp_home_menu(wa_id)
            elif message_body== "holidays_list":
                holiday_lists_template(wa_id)
                send_whatsapp_home_menu(wa_id)
            elif message_body == "pending leaves":
                view_pending_leaves(wa_id)
                send_whatsapp_home_menu(wa_id)
            elif message_body == "apply for leave":
                user_states[wa_id] = "awaiting_leave_dates"
                send_whatsapp_leave_prompt(wa_id)
            elif wa_id in user_states and user_states[wa_id] == "awaiting_leave_details":
                if "leave type:" in message_body and "start date:" in message_body and "end date:" in message_body and "half day:" in message_body:
                    leave_details = message_body
                    confirm_leave_request(wa_id, leave_details) 
                    user_states.pop(wa_id, None)  # Remove user from state after processing
                    send_whatsapp_home_menu(wa_id)
                else:
                    send_whatsapp_leave_prompt(wa_id)  # Ask again if format is incorrect
            # Check if user clicks "Exit"
            elif message_body == "exit":
                exit_confirmation_template(wa_id)
                user_states.pop(wa_id, None)  # Reset user state
            elif message_body == "end_chat":
                session_end_template(wa_id,user_name)
            else:
                process_whatsapp_message(body)

            return jsonify({"status": "ok"}), 200
        else:
            return jsonify({"status": "error", "message": "Not a WhatsApp API event"}), 404
    except json.JSONDecodeError:
        logging.error("Failed to decode JSON")
        return jsonify({"status": "error", "message": "Invalid JSON provided"}), 400

def handle_admin_flow(message_body):
    """
    Handles incoming WhatsApp messages.
    """
    body = request.get_json()

    # Check if it's a WhatsApp status update
    if (
        body.get("entry", [{}])[0]
        .get("changes", [{}])[0]
        .get("value", {})
        .get("statuses")
    ):
        logging.info("Received a WhatsApp status update.")
        return jsonify({"status": "ok"}), 200

    try:
        if is_valid_whatsapp_message(body):
            messages = body["entry"][0]["changes"][0]["value"]["messages"]
            wa_id = messages[0]["from"]
            message_body = messages[0].get("text", {}).get("body", "").strip().lower()

            # Handle different user messages
            if message_body == "admin":
                send_whatsapp_login_template(wa_id)
            elif message_body.startswith("login successful"):  # Example: "Login successful, John"
                user_name = message_body.replace("login successful", "").strip(", ")
                send_whatsapp_post_login_template(wa_id, user_name)  # Send post-login options
            elif message_body == "view_all_leave_requests":
                view_and_send_leave_requests_response(wa_id)
              # Check for Accept/Reject button clicks
            elif message_body.startswith("accept_") or message_body.startswith("reject_"):
                process_admin_decision(wa_id, message_body)
            elif message_body == "exit":
                exit_confirmation_template(wa_id)
                user_states.pop(wa_id, None)  # Reset user state
                return jsonify({"status": "ok"}), 200

            else:
                process_whatsapp_message(body)

            return jsonify({"status": "ok"}), 200
        else:
            return jsonify({"status": "error", "message": "Not a WhatsApp API event"}), 404
    except json.JSONDecodeError:
        logging.error("Failed to decode JSON")
        return jsonify({"status": "error", "message": "Invalid JSON provided"}), 400

def verify():
    # Parse params from the webhook verification request
    mode = request.args.get("hub.mode")
    token = request.args.get("hub.verify_token")
    challenge = request.args.get("hub.challenge")
    # Check if a token and mode were sent
    if mode and token:
        # Check the mode and token sent are correct
        if mode == "subscribe" and token == current_app.config["VERIFY_TOKEN"]:
            # Respond with 200 OK and challenge token from the request
            logging.info("WEBHOOK_VERIFIED")
            return challenge, 200
        else:
            # Responds with '403 Forbidden' if verify tokens do not match
            logging.info("VERIFICATION_FAILED")
            return jsonify({"status": "error", "message": "Verification failed"}), 403
    else:
        # Responds with '400 Bad Request' if verify tokens do not match
        logging.info("MISSING_PARAMETER")
        return jsonify({"status": "error", "message": "Missing parameters"}), 400


@webhook_blueprint.route("/webhook", methods=["GET"])
def webhook_get():
    logging.info("token :",current_app.config["VERIFY_TOKEN"])
    print("token :",current_app.config["VERIFY_TOKEN"])
    return verify()


@webhook_blueprint.route("/webhook", methods=["POST"])
@signature_required
def webhook_post():
    """
    Handles incoming WhatsApp messages.
    """
    body = request.get_json()

    # Check if it's a WhatsApp status update
    if (
        body.get("entry", [{}])[0]
        .get("changes", [{}])[0]
        .get("value", {})
        .get("statuses")
    ):
        logging.info("Received a WhatsApp status update.")
        return jsonify({"status": "ok"}), 200

    try:
        if is_valid_whatsapp_message(body):
            messages = body["entry"][0]["changes"][0]["value"]["messages"]
            wa_id = messages[0]["from"]
            # message_body = messages[0].get("text", {}).get("body", "").strip().lower()

            message_body = ""

            # Extract normal text messages
            if "text" in messages[0]:
                message_body = messages[0]["text"].get("body", "").strip().lower()
                print("📩 Normal text message:", message_body)

            # Extract Quick Reply button payload
            elif "interactive" in messages[0] and "button_reply" in messages[0]["interactive"]:
                message_body = messages[0]["interactive"]["button_reply"].get("id", "").strip().lower()
                print("🔘 Quick Reply button clicked, payload received:", message_body)
            
            

            # Handle different user messages
            if message_body == "hi":
                send_welcome_template(wa_id)
            elif message_body == "start":
                choose_role_template(wa_id)
            elif message_body == "admin":
                return handle_admin_flow("admin")
            elif message_body == "employee":
                return handle_employee_flow("employee")
            else:
                send_generic_response(wa_id)

    except Exception as e:
        logging.error(f"Error processing message: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

    return jsonify({"status": "ok"}), 200

def send_generic_response(wa_id):
    """
    Sends a generic response if the message is not recognized.
    """
    message = {
        "recipient": {"id": wa_id},
        "message": {
            "text": "Sorry, I didn't understand that. Please reply with 'hi' to start again."
        }
    }

    send_whatsapp_message(message)
    
def send_whatsapp_message(message):
    """
    Sends the given message to WhatsApp. Replace this with your actual sending logic.
    """
    # Logic to send the message to WhatsApp API
    logging.info(f"Sending message: {message}")
    # For actual implementation, use an API client to send the message to WhatsApp.
