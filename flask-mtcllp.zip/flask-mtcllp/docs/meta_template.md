welcome message :-
-----------------

Hello! 👋

Welcome to the MTCLLP Leave Management System WhatsApp Bot! 🌟

🌟 Here’s what you can do:

For Employees:
✅ View holiday list
✅ Apply for leave
✅ View your pending leave balance
✅ Exit chat (End session)

For Admins:
✅ View holiday list
✅ View all employees' leave requests
✅ Accept or reject leave requests
✅ Exit chat (End session)

To proceed, please click the Start button below and select your role (Admin/Employee).
Please choose your role quickly to get started!


🔽 Click *Start * to continue:
🛠️ Buttons (Quick Replies):
 Start

-----------------------------------------

choose Roles:-
-------------

Please choose your *Role* to proceed :

🔽 Click one of the buttons below to select your role: 
🛠️ Buttons (Quick Replies):
Admin 
Employee

-------------------------------------------------------------------------

login :-
-------------

Login to your account 🔐📱

To get started, simply log in using your mobile number and password. Secure and easy!

💡 Info:

Log in using your mobile number and password to access your account.
🔽 Click the button below to log in: LOGIN
         

-------------------------------------------------------------------------

post login template :-
-------------

🎉 {{username}}, You have logged in successfully! 🎉

----------------------------------------------------------------------------

employee Home menu template :-
---------------------------

What would you like to do next?


🛠️ Buttons (Quick Replies):
📋 View Pending Leaves (view_pending_leaves)
✍️ Apply for Leave (apply_leave)
🔄 View Holidays List (holidays_list)
❌ Exit Chat (exit_chat)
------------------------------------------------------------------------------

View Pending Leaves template :-
---------------------------


Your Pending Leave Balance: 📅

🔹 Restricted Holiday : {{1}} 

🔹 Sick Leave : {{2}}

🔹 Casual Leave: {{3}}

🔹 Earned Leave : {{4}}


Samples for body content:

{{1}} restricted_holiday
{{2}} sick_leave
{{3}} casual_leave
{{4}} earned_leave

------------------------------------------------------------------------------

employee_leave_prompt  template :-
---------------------------


📅 Please enter your leave details in this format:

➡️ Leave Type: Choose one from (Earned Leave, Casual Leave, Restricted Holiday, Sick Leave)  
➡️ Start Date: YYYY-MM-DD  
➡️ End Date: YYYY-MM-DD  
➡️ Half Day: Yes or No

Example: 👇

(Leave Type,Start Date,End Date,Half Day)
Casual Leave, 2024-02-10, 2024-02-15,  No

-----------------------------------------------------------------------------------------

employee_leave_request_confirmation :-
-------------------------------------

✅ {{username}} , Your leave request has been submitted successfully! 🎉

➡️ Leave Type: {{leave_type}}  
➡️ Start Date: {{start_date}}  
➡️ End Date: {{end_date}}  
➡️ Half Day: {{half_day}}

{{username}} Akshay 
{{leave_type}} Casual Leave
{{start_date}} 06=02-2025
{{end_date}} 07=02-2025
{{half_day}} No

-------------------------------------------------------------------------------------------

holiday list template :-
-------------------------

📅 Holiday List

------------------------------------
| ID  | Name                | Date     |
------------------------------------
| {{1}}   | {{2}}            |  {{3}} |


{{1}} id 
{{2}} name
{{3}} date

------------------------------------

exit_chat_template :-
---------------------

Do you want to exit the chat? ❌

Click below to end the conversation. 🛑

You can always restart the chat by sending 'hi' 👋.

🛠️ Buttons (Quick Replies):
❌ End Chat 

---------------------------------------------------------------------------------------------------------

